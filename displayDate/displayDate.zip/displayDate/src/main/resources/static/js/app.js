alert("this is the " + document.title +   "template");

